from flask import Flask, render_template, request, redirect

app = Flask(__name__)

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/produtos")
def produtos():
    return render_template("produtos.html")

@app.route("/solucoes")
def solucoes():
    return render_template("solucoes.html")

@app.route("/contato", methods=["GET", "POST"])
def contato():
    if request.method == "POST":
        nome = request.form["nome"]
        email = request.form["email"]
        mensagem = request.form["mensagem"]
        print(f"Orçamento recebido de {nome} ({email}): {mensagem}")
        return redirect("/")
    return render_template("contato.html")

if __name__ == "__main__":
    app.run(debug=True)
